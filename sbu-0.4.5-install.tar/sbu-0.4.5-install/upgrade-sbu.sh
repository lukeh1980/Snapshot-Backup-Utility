#!/bin/bash
### --------------------------------- ###
###     Copyright 2016 Luke Higgs     ###
### Contact: admin@aquariandesign.com ###
### --------------------------------- ###

# This file is part of SBU (Snapshot Backup Utility)

# SBU is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# SBU is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>.
#################################################################################################

CURRSBUVER=$(/opt/sbu/sbu --version)
NEWSBUVER="0.4.4"

echo "Upgrading SBU $CURRSBUVER to version $NEWSBUVER press y to continue..."; read upgradeSBU

if [[ $upgradeSBU == "y" ]]; then

    echo "Overwriting files..."
    # Extract SBU files to installation directory:
    if [ ! -d "/tmp/sbu" ]; then
                mkdir -p /tmp/sbu
    fi
    tar -xaf sbu-*.tar --strip-components=1 --directory /tmp/sbu
    chmod -R a+x /tmp/sbu/*
    chmod -R a+x /tmp/sbu/source/*

    yes | cp /tmp/sbu/sbu /opt/sbu/sbu
	
	yes | cp /tmp/sbu/docs/usage.txt /opt/sbu/docs/usage.txt
	yes | cp /tmp/sbu/docs/version /opt/sbu/docs/version
	
    yes | cp /tmp/sbu/source/check-config.sh        /opt/sbu/source/check-config.sh
    yes | cp /tmp/sbu/source/check-delete-queue.sh  /opt/sbu/source/check-delete-queue.sh
    yes | cp /tmp/sbu/source/clean-job.sh           /opt/sbu/source/clean-job.sh
    yes | cp /tmp/sbu/source/create-config.sh       /opt/sbu/source/create-config.sh
    yes | cp /tmp/sbu/source/create-new-job.sh      /opt/sbu/source/create-new-job.sh
    yes | cp /tmp/sbu/source/create-snapshot.sh     /opt/sbu/source/create-snapshot.sh
    yes | cp /tmp/sbu/source/functions              /opt/sbu/source/functions
    yes | cp /tmp/sbu/source/get-status.sh          /opt/sbu/source/get-status.sh
    yes | cp /tmp/sbu/source/header                 /opt/sbu/source/header
    yes | cp /tmp/sbu/source/load-config.sh         /opt/sbu/source/load-config.sh
    yes | cp /tmp/sbu/source/reinitialize-job.sh    /opt/sbu/source/reinitialize-job.sh
    yes | cp /tmp/sbu/source/remove-job.sh          /opt/sbu/source/remove-job.sh
    yes | cp /tmp/sbu/source/rotate-bu.sh           /opt/sbu/source/rotate-bu.sh
	yes | cp /tmp/sbu/source/restart-on-idle.sh     /opt/sbu/source/restart-on-idle.sh
    yes | cp /tmp/sbu/source/run-job.sh             /opt/sbu/source/run-job.sh
    yes | cp /tmp/sbu/source/search-for-changes.sh  /opt/sbu/source/search-for-changes.sh
    yes | cp /tmp/sbu/source/snapshot-rollup.sh     /opt/sbu/source/snapshot-rollup.sh
    yes | cp /tmp/sbu/source/stop-job.sh            /opt/sbu/source/stop-job.sh
    yes | cp /tmp/sbu/source/sync-changes.sh        /opt/sbu/source/sync-changes.sh
		
	echo "Upgrade Complete...You will need to restart all jobs, this should be done when they are idle. Auto restart all jobs when idle? y/n"; read yesNo

	if [[ $yesNo == "y" ]]; then
		/opt/sbu/source/restart-on-idle.sh
	fi

fi

echo ""
echo "Done upgrading..."

