#!/bin/bash
### --------------------------------- ###
###     Copyright 2016 Luke Higgs     ###
### Contact: admin@aquariandesign.com ###
### --------------------------------- ###

# This file is part of SBU (Snapshot Backup Utility)

# SBU is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# SBU is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>.
#################################################################################################

# INSTALLATION SCRIPT FOR SBU - UPDATED 7-5-2016
# SHA256 CHECKSUM:
# Run this install script in the same location as the tar file. 
# SBU will be installed in the /opt/sbu directory.
# After installation run sbu --help at a command prompt.

# check for redhat release:
if [ -e "/etc/redhat-release" ]; then
	
	if grep -q -i "release 6." /etc/redhat-release
	then
  		DIST="RHEL6"
	else
		if grep -q -i "release 7." /etc/redhat-release
		then
			DIST="RHEL7"
		fi
	fi

else

	# check for ubuntu release
	if grep -q -i "Ubuntu" /etc/lsb-release
	then
		DIST="UBUNTU"
	fi

fi

if [ -n "$DIST" ]; then

# FOUND DIST - BEGIN INSTALLATION:
##################################
echo ""
echo "-----STARTING SBU INSTALLATION-----"
echo ""

# DIST SPECIFIC COMMANDS & CHECKS:
if [ $DIST = "RHEL6" ] || [ $DIST = "RHEL7" ]; then
		
	rpm -qa | grep -qw tar || yum install tar -y
	rpm -qa | grep -qw wget || yum install wget -y
	rpm -qa | grep -qw gcc || yum install gcc -y
	rpm -qa | grep -qw make || yum install make -y
	rpm -qa | grep -qw psmisc || yum install psmisc -y
	rpm -qa | grep -qw perl || yum install perl -y
	
	if [ $DIST = "RHEL6" ]; then
		
		# NEED TO JUST MAKE /etc/rc.local executable for Centos 7 instead of trying to create a systemd service.
		if [ -e "/etc/rc.local" ]; then
			echo "Setting autostart script in /etc/rc.local..."
			grep -v "exit 0" /etc/rc.local > /etc/rc.local.tmp; mv /etc/rc.local.tmp /etc/rc.local
			echo "# SBU Autostart script:" >> /etc/rc.local
			echo "/bin/bash /opt/sbu/source/autostart.sh" >> /etc/rc.local
			echo ""
			echo "exit 0" >> /etc/rc.local
			chmod +x /etc/rc.local
		else
			echo "/etc/rc.local does not exist, could not set autostart script. Please configure /opt/sbu/autostart/autostart.sh to run on bootup to enable autostarting backups."
		fi
		
	else
	
		touch /etc/systemd/system/sbu.service
		echo "[Unit]" >> /etc/systemd/system/sbu.service
		echo "Description=Snapshot Backup Utility" >> /etc/systemd/system/sbu.service
		echo "After=network.target" >> /etc/systemd/system/sbu.service
		echo "[Service]" >> /etc/systemd/system/sbu.service
		echo "Type=simple" >> /etc/systemd/system/sbu.service
		echo "ExecStart=/opt/sbu/source/autostart.sh" >> /etc/systemd/system/sbu.service
		echo "[Install]" >> /etc/systemd/system/sbu.service
		echo "WantedBy=multi-user.target" >> /etc/systemd/system/sbu.service
	
	fi

else

	echo "Installing on Ubuntu..."
	dpkg -l | grep -qw tar || apt-get install tar
	dpkg -l | grep -qw wget || apt-get install wget
	dpkg -l | grep -qw gcc || apt-get install gcc
	dpkg -l | grep -qw make || apt-get install make
	dpkg -l | grep -qw psmisc || apt-get install psmisc
	dpkg -l | grep -qw perl || apt-get install perl
	
	touch /etc/systemd/system/sbu.service
	echo "[Unit]" >> /etc/systemd/system/sbu.service
	echo "Description=Snapshot Backup Utility" >> /etc/systemd/system/sbu.service
	echo "After=network.target" >> /etc/systemd/system/sbu.service
	echo "[Service]" >> /etc/systemd/system/sbu.service
	echo "Type=forking" >> /etc/systemd/system/sbu.service
	echo "ExecStart=/opt/sbu/source/autostart.sh" >> /etc/systemd/system/sbu.service
	echo "[Install]" >> /etc/systemd/system/sbu.service
	echo "WantedBy=multi-user.target" >> /etc/systemd/system/sbu.service
		
fi

# UNIVERSAL COMMANDS & CHECKS:
##############################

if [ ! -d "/opt" ]; then
	echo "/opt directory not found or not accessible, installation cannot continue!"
	exit
else
	mkdir /opt/sbu
	if [ ! -d "/opt/sbu" ]; then
		echo "Could not create /opt/sbu installation directory, installation cannot continue!"
		exit
	else
		mkdir /opt/sbu/jobs
		mkdir /opt/sbu/delqueue
		echo "/opt/sbu installation directory created..."
	fi
fi

if [ ! -d "/var/log" ]; then
	echo "/var/log directory not found or not accessible, installation cannot continue!"
	exit
else
	mkdir /var/log/sbu
	if [ ! -d "/opt" ]; then
		echo "Could not create /var/log/sbu log directory, installation cannot continue!"
		exit
	else
		echo "/var/log/sbu log directory created..."
	fi
fi

echo "Extracting files to /opt/sbu..."
# Extract SBU files to installation directory:
tar -xaf sbu-*.tar --strip-components=1 --directory /opt/sbu
chmod -R +x /opt/sbu/*
chmod -R +x /opt/sbu/source/*
echo ""
echo "WARNING: SBU requires rsync 3.1.2 or greater...skip this step if you need to install it on your own or already have it installed. Install RSYNC? (y/n): "; read installRSYNC

if [[ $installRSYNC == "y" ]]; then

	wget https://download.samba.org/pub/rsync/src/rsync-3.1.2.tar.gz
	tar -zxf rsync-3.1.2.tar.gz
	cd rsync-3.1.2
	./configure
	make
	make install
	
fi

if [ $DIST = "RHEL7" ] || [ $DIST = "UBUNTU" ]; then

	systemctl daemon-reload
	systemctl enable sbu.service
	systemctl start sbu.service
	
fi

echo ""
echo "### --------------------------------- ###"
echo "###     Copyright 2016 Luke Higgs     ###"
echo "### Contact: admin@aquariandesign.com ###"
echo "### --------------------------------- ###"
echo ""
echo "SBU is free software: you can redistribute it and/or modify"
echo "it under the terms of the GNU General Public License as published by"
echo "the Free Software Foundation, either version 3 of the License, or"
echo "any later version."
echo ""
echo "SBU is distributed in the hope that it will be useful,"
echo "but WITHOUT ANY WARRANTY; without even the implied warranty of"
echo "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
echo "GNU General Public License for more details."
echo ""
echo "You should have received a copy of the GNU General Public License"
echo "along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>."
echo "#################################################################################################"
echo ""
echo "Installation complete! Type sbu --help for usage, sbu --version to view installed version."
echo ""

# Set PATH:
echo "export PATH=$PATH:/opt/sbu" >> ~/.bashrc
exec bash

# NO DIST FOUND - EXIT:
#######################
else
echo "Could not detect Linux distribution, please manually install SBU."
exit
fi
