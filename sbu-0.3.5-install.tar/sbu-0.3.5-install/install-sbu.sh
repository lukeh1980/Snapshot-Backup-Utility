#!/bin/bash
### --------------------------------- ###
###     Copyright 2016 Luke Higgs     ###
### Contact: admin@aquariandesign.com ###
### --------------------------------- ###

# This file is part of SBU (Snapshot Backup Utility)

# SBU is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# SBU is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>.
#################################################################################################

# INSTALLATION SCRIPT FOR SBU - UPDATED 7-5-2016
# SHA256 CHECKSUM:
# Run this install script in the same location as the tar file. 
# SBU will be installed in the /opt/sbu directory.
# After installation run sbu --help at a command prompt.

echo ""
echo "-----STARTING SBU INSTALLATION-----"
echo ""
if [ ! -d "/opt" ]; then
	echo "/opt directory not found or not accessible, installation cannot continue!"
	exit
else
	mkdir /opt/sbu
	if [ ! -d "/opt" ]; then
		echo "Could not create /opt/sbu installation directory, installation cannot continue!"
		exit
	else
		echo "/opt/sbu installation directory created..."
	fi
fi

if [ ! -d "/var/log" ]; then
	echo "/var/log directory not found or not accessible, installation cannot continue!"
	exit
else
	mkdir /var/log/sbu
	if [ ! -d "/opt" ]; then
		echo "Could not create /var/log/sbu log directory, installation cannot continue!"
		exit
	else
		echo "/var/log/sbu log directory created..."
	fi
fi

if [ -e "/etc/rc.local" ]; then
	echo "Setting autostart script in /etc/rc.local..."
	grep -v "exit 0" /etc/rc.local > /etc/rc.local.tmp; mv /etc/rc.local.tmp /etc/rc.local
	echo "# SBU Autostart script:" >> /etc/rc.local
	echo "/bin/bash /opt/sbu/source/autostart.sh" >> /etc/rc.local
	echo ""
	echo "exit 0" >> /etc/rc.local
	chmod +x /etc/rc.local
else
	echo "/etc/rc.local does not exist, could not set autostart script. Please set /opt/sbu/autostart/autostart.sh to run on bootup to enable autostarting backups."
fi

echo "Extracting files to /opt/sbu..."
# Extract SBU files to installation directory:
tar -xaf sbu-*.tar --strip-components=1 --directory /opt/sbu
chmod -R a+x /opt/sbu/*
chmod -R a+x /opt/sbu/source/*
echo ""
echo "WARNING: SBU requires rsync...skip this step if you need to install it on your own or already have it installed. Install RSYNC? (y/n): "; read installRSYNC

if [[ $installRSYNC == "y" ]]; then

	if [ -s /etc/redhat-release ]; then
		yum -y install rsync
	else
		apt-get -y install rsync
	fi
	
fi

echo ""
echo "### --------------------------------- ###"
echo "###     Copyright 2016 Luke Higgs     ###"
echo "### Contact: admin@aquariandesign.com ###"
echo "### --------------------------------- ###"
echo ""
echo "SBU is free software: you can redistribute it and/or modify"
echo "it under the terms of the GNU General Public License as published by"
echo "the Free Software Foundation, either version 3 of the License, or"
echo "any later version."
echo ""
echo "SBU is distributed in the hope that it will be useful,"
echo "but WITHOUT ANY WARRANTY; without even the implied warranty of"
echo "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
echo "GNU General Public License for more details."
echo ""
echo "You should have received a copy of the GNU General Public License"
echo "along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>."
echo "#################################################################################################"
echo ""
echo "Installation complete! Type sbu --help for usage."
echo ""

# Set PATH:
echo "export PATH=$PATH:/opt/sbu" >> ~/.bashrc
exec bash
