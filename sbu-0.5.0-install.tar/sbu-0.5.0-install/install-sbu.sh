#!/bin/bash
### --------------------------------- ###
###     Copyright 2016 Luke Higgs     ###
### Contact: admin@aquariandesign.com ###
### --------------------------------- ###

# This file is part of SBU (Snapshot Backup Utility)

# SBU is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# SBU is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>.
#################################################################################################

# INSTALLATION SCRIPT FOR SBU 0.5.0
# Run this install script in the same location as the tar file.
# SBU will be installed in the /opt/sbu directory.
# rsync is installed from the distribution's package manager; SBU needs rsync 3.1.2 or later.
# Supported package managers: apt (Debian/Ubuntu), dnf/yum (RHEL/Rocky/Alma/Fedora), zypper (SUSE), pacman (Arch).
# To upgrade an existing installation use upgrade-sbu.sh instead.
# After installation run sbu --help at a command prompt.

MIN_RSYNC="3.1.2"
SYSTEM_PATH="/usr/sbin:/usr/bin:/sbin:/bin"

die() { echo ""; echo "ERROR: $*" >&2; exit 1; }

# ver_ge A B: true if version A >= version B
ver_ge() { [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]; }

rsync_version() { "$1" --version 2>/dev/null | awk 'NR==1{for(i=1;i<=NF;i++) if($i=="version"){print $(i+1); exit}}'; }

# The distribution's rsync: resolved from the system directories only, so a hand-built
# copy in /usr/local/bin is not mistaken for it.
distro_rsync() { ( PATH="$SYSTEM_PATH"; hash -r; command -v rsync ) 2>/dev/null; }

cd "$(dirname "$0")" || die "cannot change to the installer directory"

[ "$(id -u)" -eq 0 ] || die "please run the installer as root (e.g. sudo ./install-sbu.sh)."

if [ -e "/opt/sbu/sbu" ]; then
	die "SBU $(tr -d '[:space:]' < /opt/sbu/docs/version 2>/dev/null) is already installed in /opt/sbu. Use ./upgrade-sbu.sh to upgrade it."
fi

TARFILE=$(ls sbu-*.tar 2>/dev/null | head -n1)
[ -n "$TARFILE" ] || die "sbu-x.x.x.tar not found next to install-sbu.sh."

# Detect the package manager:
if command -v apt-get >/dev/null 2>&1; then PM="apt"
elif command -v dnf >/dev/null 2>&1; then PM="dnf"
elif command -v yum >/dev/null 2>&1; then PM="yum"
elif command -v zypper >/dev/null 2>&1; then PM="zypper"
elif command -v pacman >/dev/null 2>&1; then PM="pacman"
else PM=""
fi

pm_install() {
	case "$PM" in
		apt)    DEBIAN_FRONTEND=noninteractive apt-get install -y "$@" \
		        || { apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y "$@"; } ;;
		dnf)    dnf install -y "$@" ;;
		yum)    yum install -y "$@" ;;
		zypper) zypper --non-interactive install "$@" ;;
		pacman) pacman -S --noconfirm --needed "$@" ;;
		*)      return 1 ;;
	esac
}

echo ""
echo "-----STARTING SBU INSTALLATION-----"
echo ""

# rsync (from the distribution):
RSYNC=$(distro_rsync)
if [ -z "$RSYNC" ]; then
	[ -n "$PM" ] || die "rsync is not installed and no supported package manager was found. Install rsync $MIN_RSYNC or later with your package manager and run the installer again."
	echo "Installing rsync with $PM..."
	pm_install rsync || die "could not install rsync with $PM."
	RSYNC=$(distro_rsync)
	[ -n "$RSYNC" ] || die "rsync was installed but cannot be found in $SYSTEM_PATH."
fi
RSYNCVER=$(rsync_version "$RSYNC")
if ! ver_ge "${RSYNCVER:-0}" "$MIN_RSYNC"; then
	die "the distribution's rsync ($RSYNC) is version ${RSYNCVER:-unknown}; SBU needs $MIN_RSYNC or later. Please use a newer distribution release."
fi
echo "Using rsync $RSYNCVER ($RSYNC)"

if [ -x /usr/local/bin/rsync ] && ! [ /usr/local/bin/rsync -ef "$RSYNC" ]; then
	echo "NOTE: /usr/local/bin/rsync ($(rsync_version /usr/local/bin/rsync)) also exists. It comes before $RSYNC on most PATHs,"
	echo "      so SBU will use it instead of the distribution's rsync. Remove it to use the distribution's rsync."
fi

# pgrep/pkill (procps):
if ! command -v pgrep >/dev/null 2>&1 || ! command -v pkill >/dev/null 2>&1; then
	echo "Installing procps (pgrep/pkill)..."
	case "$PM" in
		apt|zypper) pm_install procps ;;
		*)          pm_install procps-ng ;;
	esac || die "could not install procps (pgrep/pkill)."
fi

# Create installation and log directories:
if [ ! -d "/opt" ]; then
	die "/opt directory not found or not accessible, installation cannot continue!"
fi
mkdir -p /opt/sbu/jobs /opt/sbu/delqueue || die "could not create /opt/sbu installation directory, installation cannot continue!"
echo "/opt/sbu installation directory created..."
mkdir -p /var/log/sbu || die "could not create /var/log/sbu log directory, installation cannot continue!"
echo "/var/log/sbu log directory created..."

echo "Extracting files to /opt/sbu..."
tar -xf "$TARFILE" --strip-components=1 --directory /opt/sbu || die "could not extract $TARFILE"
chmod -R +x /opt/sbu/*
chmod -R +x /opt/sbu/source/*

# Autostart on boot:
if command -v systemctl >/dev/null 2>&1 && [ -d /etc/systemd/system ]; then
	echo "Creating SystemD unit file /etc/systemd/system/sbu.service..."
	cat > /etc/systemd/system/sbu.service <<'EOF'
[Unit]
Description=Snapshot Backup Utility
After=network.target
[Service]
Type=forking
ExecStart=/opt/sbu/source/autostart.sh
[Install]
WantedBy=multi-user.target
EOF
	systemctl enable sbu.service >/dev/null 2>&1 || echo "WARNING: could not enable sbu.service, run: systemctl enable sbu.service"
	if [ -d /run/systemd/system ]; then
		systemctl daemon-reload
		systemctl start sbu.service || echo "WARNING: could not start sbu.service, check: systemctl status sbu.service"
	fi
else
	RCLOCAL=""
	[ -e /etc/rc.d/rc.local ] && RCLOCAL="/etc/rc.d/rc.local"
	[ -z "$RCLOCAL" ] && [ -e /etc/rc.local ] && RCLOCAL="/etc/rc.local"
	if [ -n "$RCLOCAL" ]; then
		if ! grep -q "/opt/sbu/source/autostart.sh" "$RCLOCAL"; then
			echo "Setting autostart script in $RCLOCAL..."
			grep -v "^exit 0" "$RCLOCAL" > "$RCLOCAL.tmp"; mv "$RCLOCAL.tmp" "$RCLOCAL"
			echo "# SBU Autostart script:" >> "$RCLOCAL"
			echo "/bin/bash /opt/sbu/source/autostart.sh" >> "$RCLOCAL"
			echo "exit 0" >> "$RCLOCAL"
			chmod +x "$RCLOCAL"
		fi
	else
		echo "WARNING: neither SystemD nor rc.local was found. Configure /opt/sbu/source/autostart.sh to run on bootup to enable autostarting backups."
	fi
fi

echo ""
echo "### --------------------------------- ###"
echo "###     Copyright 2016 Luke Higgs     ###"
echo "### Contact: admin@aquariandesign.com ###"
echo "### --------------------------------- ###"
echo ""
echo "SBU is free software: you can redistribute it and/or modify"
echo "it under the terms of the GNU General Public License as published by"
echo "the Free Software Foundation, either version 3 of the License, or"
echo "any later version."
echo ""
echo "SBU is distributed in the hope that it will be useful,"
echo "but WITHOUT ANY WARRANTY; without even the implied warranty of"
echo "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the"
echo "GNU General Public License for more details."
echo ""
echo "You should have received a copy of the GNU General Public License"
echo "along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>."
echo "#################################################################################################"
echo ""

# Set PATH:
if ! grep -qxF 'export PATH="$PATH:/opt/sbu"' ~/.bashrc 2>/dev/null; then
	echo 'export PATH="$PATH:/opt/sbu"' >> ~/.bashrc
fi

echo "Installation complete! Open a new shell (or run: source ~/.bashrc), then type sbu --help for usage, sbu --version to view installed version."
echo ""
