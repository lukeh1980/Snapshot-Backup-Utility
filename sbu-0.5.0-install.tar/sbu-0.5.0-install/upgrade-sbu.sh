#!/usr/bin/env bash
#################################################################################################
# upgrade.sh - in-place upgrade of Snapshot Backup Utility (SBU) 0.4.5 -> 0.5.0
#
# Usage:
#   ./upgrade.sh [--package PATH] [--yes] [--no-restart] [--timeout SECS] [--force]
#                [--keep-source-rsync]
#   ./upgrade.sh --check [--package PATH]          # preflight only, changes nothing
#   ./upgrade.sh --rollback [BACKUP_DIR] [--yes]   # restore the pre-upgrade 0.4.5 code
#
# PATH may be sbu-0_5_0-fixed.zip, a tar, the extracted repo directory, or its SOURCE/ directory.
# If omitted, the script searches its own directory for a 0.5.0 package.
#
# What it does:
#   1. Preflight: root, installed version is 0.4.5, package matches the validated 0.5.0 build
#      (SHA-256 manifest below), the distribution's rsync is (or can be) installed and is
#      >= 3.1.2, every job config parses, and flags anything whose behaviour changes.
#   2. Quiesce: waits until each running job is idle (only the interval `sleep` running under
#      run-job.sh), freezes it with SIGSTOP to close the race, then terminates it. It never
#      interrupts a search, snapshot copy, sync, rotation, rollup or job initialisation.
#   3. Backup: copies /opt/sbu to /var/backups/sbu/ (used by --rollback and by auto-restore).
#   4. Install: stages files on the same filesystem and swaps each one in with an atomic mv.
#      source/autostart.sh and source/jobs-list are runtime files and are preserved.
#      Job configs, job state (/opt/sbu/jobs) and backup data (snapshots) are never modified.
#   5. Migrate transient state: removes 0.4.5's tmp/<interval>-min change lists and retires the
#      pre-built tmp/<job>.0 staging copy (built by 0.4.5's symlink-dereferencing cp) via SBU's
#      own delete queue, so 0.5.0 rebuilds it.
#   6. rsync: 0.5.0 uses the distribution's rsync. The rsync package is installed if missing,
#      and the rsync 0.4.5's installer compiled into /usr/local/bin (which would otherwise
#      shadow it on PATH) is renamed to /usr/local/bin/rsync.sbu-retired. --rollback puts it
#      back. --keep-source-rsync keeps using the compiled rsync instead (autostart.sh then
#      gets a PATH line so boot-time starts find it first).
#   7. Verify installed files against the manifest, restart the jobs that were running, and
#      confirm they are up.
#
# Exit codes: 0 ok / already current, 1 preflight failed, 2 usage, 3 quiesce timed out
# (nothing installed, jobs restarted), 4 install failed (0.4.5 restored, jobs restarted).
#################################################################################################

set -u
umask 022

FROM_VERSION="0.4.5"
TO_VERSION="0.5.0"
SBU_HOME="/opt/sbu"
BACKUP_ROOT="/var/backups/sbu"
MIN_RSYNC="3.1.2"
TS="$(date +%Y%m%d-%H%M%S)"
LOG_DIR="/var/log/sbu"
LOG="$LOG_DIR/upgrade-$TS.log"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LEGACY_RSYNC="/usr/local/bin/rsync"
RETIRED_RSYNC="/usr/local/bin/rsync.sbu-retired"
SYSTEM_PATH="/usr/sbin:/usr/bin:/sbin:/bin"
PIN_LINE='export PATH="/usr/local/bin:$PATH"  # sbu-upgrade-0.5.0: 0.5.0 finds rsync via PATH; keep 0.4.5'"'"'s /usr/local/bin/rsync'
MARKERS=(searching currently-taking-snapshot syncing-changes rolling-up-backup rotating-backup)

# Files that are rewritten by SBU at runtime and must survive an upgrade untouched.
RUNTIME_FILES=("source/autostart.sh" "source/jobs-list")

# Files 0.4.5 shipped that 0.5.0 no longer has (unused scripts and the list check-config.sh wrote).
# They are removed on upgrade; they remain in the pre-upgrade backup and --rollback restores them.
OBSOLETE_FILES=("source/check-config.sh" "source/load-config.sh" "source/restart-on-idle.sh" "source/jobs-list")

# SHA-256 of every file in the validated SBU 0.5.0 build: tag v0.5.0 plus the FullSync=off/--stop fix,
# distribution-rsync installer and cleanup commits (sbu-0_5_0-fixed.zip / sbu-0.5.0-install.tar).
read -r -d '' MANIFEST <<'EOF'
b3d1eae7f524fc9ddd48562a4652efd2bcd848e38b03f05e388bcce943e73df2  docs/COPYING
fe50413c57d76c543ec196b290078c50e08759b83f5ccef4cab2238c5c49df95  docs/license.txt
19e592c601a7e166853a945673d2fbd41ac676d26cc681f227c8ba87d7a09b8c  docs/usage.txt
a0ad50640139a524f86591157145bf1d4674ea9c065bfea21558f0f7b04430c8  docs/version
47e306cebd7832d2b9a6e56451d898290d2f7a513ac2eb2eafbcee68f8983d31  sbu
e7767f1dc175cdfc73b7a5a419ca695f80660af67d4c94ce3a75306fbc78b457  source/autostart.sh
bdd829b394daab30b283ac53356aec7118bd69221edf7bb74c30008d6bb5bff5  source/check-delete-queue.sh
8897819c7c3858ef42ce4a446acefa153285884a9524d459e45fb0cbd81d7ad2  source/clean-job.sh
b54978ffa933f855b37e577a5815d16fd6c8adc747e5b29d47f7c151c725a45e  source/create-config.sh
df8c4d9c31ddffe90b30bb870b2162a80d79800954206b8cd15e554aa06d0482  source/create-new-job.sh
b86f53bb0feac4c534d24ac25a377a39b9de4402e778f7f4f55f59742978f43a  source/create-snapshot.sh
8085d43a2e3c28a25a7b82f147c6e0dede55b67cec0bf52569ad6311ccebf137  source/functions
16b85cf2408069fd932933e232066518a28678279b54f65a1d859faa13567d57  source/get-status.sh
815c56dd2cca6c9bbc2a1d27aa840cae51d3c1fe1d477178c19ff2f0392d4657  source/header
5a89034f64cd5161f716cffdf632a49c2dccf7c4d24cbd253c9d2008190e1abb  source/reinitialize-job.sh
1f40d6a9968605c91d5b68cc333dcfab5b2c95f702345fbbe43092ac4bcb62e4  source/remove-job.sh
37672dfd6966525f738baabae1ed2725adaa6e5716aca71881fefd57e2afb600  source/rotate-bu.sh
d5c14952211fb78404e59eddc775f84ff27dc25807517e2297850243b0afbbda  source/run-job.sh
4d226caa5222b70edaba4c92549b3869a65f58854455436886bc3b417f663850  source/search-for-changes.sh
870c4c2725be2dbc3b746b68fa9300d4e667206789926713415438de7518aa9c  source/snapshot-rollup.sh
7f8116c6fa174e34859c17b01e725eb3aee8fb92c03547917a2bc267414a555d  source/stop-job.sh
ef3114ca1faf869b8550ca73ad0fc639b1147818dfaa40d0e8bd32afcea83a36  source/sync-changes.sh
EOF

# ---------------------------------------------------------------------------------------------
# Output helpers
# ---------------------------------------------------------------------------------------------
_log() { [ -n "${LOG_READY:-}" ] && printf '%s %s\n' "$(date '+%F %T')" "$*" >> "$LOG"; return 0; }
info() { printf '  %s\n' "$*"; _log "INFO  $*"; }
ok()   { printf '  [ok]   %s\n' "$*"; _log "OK    $*"; }
warn() { printf '  [warn] %s\n' "$*" >&2; _log "WARN  $*"; WARNINGS=$((WARNINGS + 1)); }
fail() { printf '  [FAIL] %s\n' "$*" >&2; _log "FAIL  $*"; FAILURES=$((FAILURES + 1)); }
die()  { printf '\nERROR: %s\n' "$*" >&2; _log "ERROR $*"; cleanup_work; exit "${2:-1}"; }
step() { printf '\n== %s\n' "$*"; _log "STEP  $*"; }
WARNINGS=0; FAILURES=0

usage() { sed -n '3,/^###*$/{s/^# \{0,1\}//;p}' "${BASH_SOURCE[0]}" | sed '$d'; exit "${1:-0}"; }

# ---------------------------------------------------------------------------------------------
# Arguments
# ---------------------------------------------------------------------------------------------
MODE="upgrade"; PACKAGE=""; ASSUME_YES=0; NO_RESTART=0; FORCE=0; TIMEOUT=3600; ROLLBACK_DIR=""; KEEP_SOURCE_RSYNC=0
while [ $# -gt 0 ]; do
	case "$1" in
		--package)    [ $# -ge 2 ] || usage 2; PACKAGE="$2"; shift ;;
		--package=*)  PACKAGE="${1#*=}" ;;
		-y|--yes)     ASSUME_YES=1 ;;
		--no-restart) NO_RESTART=1 ;;
		--force)      FORCE=1 ;;
		--keep-source-rsync) KEEP_SOURCE_RSYNC=1 ;;
		--timeout)    [ $# -ge 2 ] || usage 2; TIMEOUT="$2"; shift ;;
		--timeout=*)  TIMEOUT="${1#*=}" ;;
		--check)      MODE="check" ;;
		--rollback)   MODE="rollback"
		              if [ $# -ge 2 ] && [ "${2#-}" = "$2" ]; then ROLLBACK_DIR="$2"; shift; fi ;;
		-h|--help)    usage 0 ;;
		*)            echo "Unknown option: $1" >&2; usage 2 ;;
	esac
	shift
done
[[ "$TIMEOUT" =~ ^[0-9]+$ ]] || { echo "--timeout needs a number of seconds" >&2; exit 2; }

# ---------------------------------------------------------------------------------------------
# Generic helpers
# ---------------------------------------------------------------------------------------------
WORK=""
cleanup_work() { [ -n "$WORK" ] && [ -d "$WORK" ] && rm -rf "$WORK"; WORK=""; return 0; }

sha_of() { sha256sum "$1" 2>/dev/null | cut -c1-64; }

ver_ge() { [ "$(printf '%s\n%s\n' "$2" "$1" | sort -V | head -n1)" = "$2" ]; }

installed_version() { tr -d '[:space:]' < "$SBU_HOME/docs/version" 2>/dev/null; }

# Read KEY from a job config exactly the way 0.5.0's load_job_config does:
# comment lines skipped, key anchored at line start (after read's whitespace trim),
# value is everything after the first "=", last occurrence wins.
conf_get_new() {
	awk -v k="$1" '
		{ sub(/^[ \t]+/, ""); sub(/[ \t]+$/, "") }
		/^#/ { next }
		index($0, k "=") == 1 { v = substr($0, length(k) + 2) }
		END { print v }' "$2"
}

# Read KEY the way 0.4.5's header/load-config loops did: any non-comment line containing
# "KEY=" anywhere, value is the second "="-separated field, last occurrence wins.
conf_get_old() {
	awk -v k="$1" '
		{ sub(/^[ \t]+/, ""); sub(/[ \t]+$/, "") }
		/^#/ { next }
		index($0, k "=") > 0 { split($0, f, "="); v = f[2] }
		END { print v }' "$2"
}

# Which rsync would `command -v rsync` pick with the given PATH?
rsync_under_path() { ( PATH="$1"; hash -r; command -v rsync 2>/dev/null ) || true; }
rsync_version() { "$1" --version 2>/dev/null | awk 'NR==1{for(i=1;i<=NF;i++) if($i=="version"){print $(i+1); exit}}'; }

list_jobs() {
	local d
	for d in "$SBU_HOME"/jobs/*/; do
		[ -d "$d" ] || continue
		basename "$d"
	done
}

# ---------------------------------------------------------------------------------------------
# Process discovery. Matching is done on exact argv, never on substrings: SBU's own
# `pgrep -f "run-job.sh NAME"` also matches job "NAME2", and any shell whose command line merely
# mentions the path.
# ---------------------------------------------------------------------------------------------
# sbu_script_pids SCRIPT [ARGPOS VALUE] - PIDs of "bash /opt/sbu/source/SCRIPT ..." processes,
# optionally only those whose argv[ARGPOS] equals VALUE.
sbu_script_pids() {
	local script="$SBU_HOME/source/$1" pos="${2:-}" val="${3:-}" p a0 a1 a2 a3 a4
	for p in /proc/[0-9]*; do
		a0=""; a1=""; a2=""; a3=""; a4=""
		{ IFS= read -r -d '' a0; IFS= read -r -d '' a1; IFS= read -r -d '' a2
		  IFS= read -r -d '' a3; IFS= read -r -d '' a4; } 2>/dev/null < "$p/cmdline"
		[ "$a1" = "$script" ] || continue
		case "${a0##*/}" in bash|sh) ;; *) continue ;; esac
		if [ -n "$pos" ]; then
			local -a argv=("$a0" "$a1" "$a2" "$a3" "$a4")
			[ "${argv[$pos]}" = "$val" ] || continue
		fi
		echo "${p#/proc/}"
	done
}
runjob_pids() { sbu_script_pids run-job.sh 2 "$1"; }

descendants() { # all descendant PIDs of $1
	ps -e -o pid= -o ppid= | awk -v root="$1" '
		{ kids[$2] = kids[$2] " " $1 }
		END { q = root; while (q != "") { split(q, a, " "); q = "";
		        for (i in a) { n = split(kids[a[i]], c, " ");
		          for (j = 1; j <= n; j++) { print c[j]; q = q " " c[j] } } } }'
}

comm_of() { cat "/proc/$1/comm" 2>/dev/null; }

# A job is idle when nothing but `sleep` is running beneath its run-job.sh. Every piece of real
# work (search, cp snapshot, sync, rotate, rollup) runs as a descendant, so this cannot miss one.
busy_children() {
	local c
	for c in $(descendants "$1"); do
		[ -d "/proc/$c" ] || continue
		[ "$(comm_of "$c")" = "sleep" ] || printf '%s(%s) ' "$(comm_of "$c")" "$c"
	done
}

# stop_job_when_idle NAME DEADLINE -> 0 stopped, 1 timed out
stop_job_when_idle() {
	local name="$1" deadline="$2" pid busy next_note=0 now kids k
	while :; do
		pid="$(runjob_pids "$name" | head -n1)"
		# A job still initialising (initial full backup) must finish first.
		if [ -n "$(sbu_script_pids create-new-job.sh 4 "$name")$(sbu_script_pids reinitialize-job.sh 2 "$name")" ]; then
			busy="initialising"
		elif [ -z "$pid" ]; then
			return 0
		else
			busy="$(busy_children "$pid")"
			if [ -z "$busy" ]; then
				kill -STOP "$pid" 2>/dev/null
				sleep 0.3
				busy="$(busy_children "$pid")"
				if [ -z "$busy" ]; then
					kids="$(descendants "$pid")"
					for k in $kids; do kill -TERM "$k" 2>/dev/null; done
					kill -TERM "$pid" 2>/dev/null
					kill -CONT "$pid" 2>/dev/null
					for _ in 1 2 3 4 5 6 7 8 9 10; do [ -d "/proc/$pid" ] || break; sleep 0.2; done
					[ -d "/proc/$pid" ] && kill -KILL "$pid" 2>/dev/null
					return 0
				fi
				kill -CONT "$pid" 2>/dev/null
			fi
		fi

		now=$(date +%s)
		[ "$now" -ge "$deadline" ] && return 1
		if [ "$now" -ge "$next_note" ]; then
			info "$name is busy ($busy) - waiting for it to go idle..."
			next_note=$((now + 30))
		fi
		sleep 2
	done
}

# ---------------------------------------------------------------------------------------------
# Package handling
# ---------------------------------------------------------------------------------------------
PKG_DIR=""
find_source_dirs() { # dirs under $1 that look like an SBU SOURCE tree
	find "$1" -maxdepth 5 -type f -path '*/source/functions' 2>/dev/null | while read -r f; do
		local d; d="$(dirname "$(dirname "$f")")"
		[ -f "$d/sbu" ] && [ -f "$d/docs/version" ] && echo "$d"
	done
}

resolve_package() {
	local src="$PACKAGE" d cand=()
	WORK="$(mktemp -d /tmp/sbu-upgrade.XXXXXX)" || die "cannot create a work directory"
	if [ -z "$src" ]; then
		for d in "$SCRIPT_DIR"/sbu-0_5_0-fixed.zip "$SCRIPT_DIR"/sbu-0_5_0.zip "$SCRIPT_DIR"/sbu-0.5.0*.zip "$SCRIPT_DIR"/sbu-0.5.0*.tar*; do
			[ -f "$d" ] && { src="$d"; break; }
		done
		[ -z "$src" ] && src="$SCRIPT_DIR"
	fi
	[ -e "$src" ] || die "package not found: $src"
	if [ -f "$src" ]; then
		case "$src" in
			*.zip)
				if command -v unzip >/dev/null; then unzip -q "$src" -d "$WORK/pkg" || die "cannot unzip $src"
				elif command -v python3 >/dev/null; then python3 -m zipfile -e "$src" "$WORK/pkg" || die "cannot unzip $src"
				else die "need unzip (or python3) to read $src"; fi ;;
			*.tar|*.tar.*|*.tgz)
				mkdir -p "$WORK/pkg" && tar -xf "$src" -C "$WORK/pkg" || die "cannot extract $src" ;;
			*) die "unsupported package type: $src" ;;
		esac
		src="$WORK/pkg"
	fi
	mapfile -t cand < <(find_source_dirs "$src")
	for d in ${cand[@]+"${cand[@]}"}; do
		if [ "$(tr -d '[:space:]' < "$d/docs/version")" = "$TO_VERSION" ]; then PKG_DIR="$d"; break; fi
	done
	[ -n "$PKG_DIR" ] || die "no SBU $TO_VERSION source tree found in ${PACKAGE:-$SCRIPT_DIR} (use --package)"
}

verify_tree_against_manifest() { # DIR -> prints mismatches, returns count
	local dir="$1" sum rel bad=0
	while read -r sum rel; do
		[ -z "$rel" ] && continue
		if [ ! -f "$dir/$rel" ]; then echo "missing: $rel"; bad=$((bad + 1))
		elif [ "$(sha_of "$dir/$rel")" != "$sum" ]; then echo "differs: $rel"; bad=$((bad + 1)); fi
	done <<< "$MANIFEST"
	return $bad
}

manifest_files() { awk 'NF==2{print $2}' <<< "$MANIFEST"; }

is_runtime_file() { local r; for r in "${RUNTIME_FILES[@]}"; do [ "$1" = "$r" ] && return 0; done; return 1; }

# install_tree FROM_DIR FILE... : stage every file next to its target, then atomic-rename each.
# A running bash keeps reading the old inode, so nothing already executing is disturbed.
install_tree() {
	local from="$1"; shift
	local rel tgt stage staged=()
	for rel in "$@"; do
		tgt="$SBU_HOME/$rel"
		mkdir -p "$(dirname "$tgt")" || return 1
		stage="$(dirname "$tgt")/.$(basename "$tgt").sbu-upgrade.$$"
		cp -p "$from/$rel" "$stage" || { rm -f ${staged[@]+"${staged[@]}"} "$stage"; return 1; }
		chmod 0755 "$stage"  # install-sbu.sh did chmod -R +x on the whole tree
		staged+=("$stage")
	done
	local i=0
	for rel in "$@"; do
		mv -f "${staged[$i]}" "$SBU_HOME/$rel" || return 1
		i=$((i + 1))
	done
	return 0
}

# ---------------------------------------------------------------------------------------------
# Job inventory / preflight
# ---------------------------------------------------------------------------------------------
declare -A JOB_DEST
RUNNING_JOBS=()
PIN_RSYNC=0

preflight_common() {
	[ "$(id -u)" -eq 0 ] || die "must be run as root (SBU lives in $SBU_HOME and runs as root)"
	[ "${BASH_VERSINFO[0]}" -ge 4 ] || die "bash >= 4 required"
	[ -d "$SBU_HOME" ] && [ -f "$SBU_HOME/sbu" ] && [ -f "$SBU_HOME/docs/version" ] \
		|| die "no SBU installation found in $SBU_HOME"
	local t
	for t in awk sed sort ps mktemp sha256sum cp mv tar pgrep pkill; do
		command -v "$t" >/dev/null || die "required tool missing: $t"
	done
}

inventory_jobs() {
	local name conf k o n dest iv rt au
	RUNNING_JOBS=()
	for name in $(list_jobs); do
		conf="$SBU_HOME/jobs/$name/$name.conf"
		if [ ! -s "$conf" ]; then warn "job '$name' has no config ($conf) - skipped"; continue; fi
		for k in Name Source Dest Interval Retention Autostart FullSync DestPerms DestOwner DestGroup ExcludeFile; do
			o="$(conf_get_old "$k" "$conf")"; n="$(conf_get_new "$k" "$conf")"
			if [ "$o" != "$n" ]; then
				warn "job '$name': $k was read by $FROM_VERSION as '$o' but $TO_VERSION reads '$n' (0.4.5 truncated values at '='; 0.5.0 uses the full value)"
			fi
		done
		iv="$(conf_get_new Interval "$conf")"; rt="$(conf_get_new Retention "$conf")"; au="$(conf_get_new Autostart "$conf")"
		if ! [[ "$rt" =~ ^[0-9]+$ ]] || ! [[ "$iv" =~ ^[0-9]+$ ]] || { [ "$au" != "on" ] && [ "$au" != "off" ]; }; then
			warn "job '$name' has a scrambled config (Interval=$iv Retention=$rt Autostart=$au). It was most likely created without --retention or --interval, which shifted every later value into the wrong key. A non-numeric Retention means 0 days: each snapshot is rolled into $name.full on the next cycle and no history is kept, in 0.4.5 and 0.5.0 alike. This upgrade does not change configs; fix it with 'sbu --set-retention 30 --name $name'$( [[ "$iv" =~ ^[0-9]+$ ]] || echo " and 'sbu --set-interval 60 --name $name'" ), then check Autostart, DestPerms, DestOwner, DestGroup and ExcludeFile in $conf."
		fi
		dest="$(conf_get_new Dest "$conf")"
		JOB_DEST[$name]="$dest"
		[ -z "$(conf_get_new Source "$conf")" ] && warn "job '$name': no Source= in config"
		if [ -z "$dest" ] || [ ! -d "$dest/$name/snapshots" ]; then
			warn "job '$name': snapshot directory $dest/$name/snapshots not found (not initialised yet, or Dest is unmounted)"
		fi
		if [ -n "$(runjob_pids "$name")$(sbu_script_pids create-new-job.sh 4 "$name")$(sbu_script_pids reinitialize-job.sh 2 "$name")" ]; then
			RUNNING_JOBS+=("$name")
		fi
	done
}

# The distribution's rsync, resolved from the system directories only.
distro_rsync() { rsync_under_path "$SYSTEM_PATH"; }

detect_pm() {
	local pm
	for pm in apt-get dnf yum zypper pacman; do command -v "$pm" >/dev/null 2>&1 && { echo "$pm"; return; }; done
}

pm_install_rsync() {
	case "$(detect_pm)" in
		apt-get) DEBIAN_FRONTEND=noninteractive apt-get install -y rsync \
		         || { apt-get update && DEBIAN_FRONTEND=noninteractive apt-get install -y rsync; } ;;
		dnf)     dnf install -y rsync ;;
		yum)     yum install -y rsync ;;
		zypper)  zypper --non-interactive install rsync ;;
		pacman)  pacman -S --noconfirm --needed rsync ;;
		*)       return 1 ;;
	esac
}

pkg_owns() { # true if a package manager claims the file
	{ command -v dpkg >/dev/null && dpkg -S "$1" >/dev/null 2>&1; } ||
	{ command -v rpm  >/dev/null && rpm -qf "$1" >/dev/null 2>&1; } ||
	{ command -v pacman >/dev/null && pacman -Qo "$1" >/dev/null 2>&1; }
}

NEED_RSYNC_PKG=0; RETIRE_RSYNC=0
check_rsync() {
	local distro v lv
	RETIRE_RSYNC=0; PIN_RSYNC=0
	distro="$(distro_rsync)"
	if [ -z "$distro" ]; then
		[ -n "$(detect_pm)" ] || die "the distribution's rsync is not installed and no supported package manager (apt, dnf, yum, zypper, pacman) was found; install rsync >= $MIN_RSYNC first"
		NEED_RSYNC_PKG=1
		info "rsync package: not installed - will be installed with $(detect_pm)"
	else
		v="$(rsync_version "$distro")"
		ver_ge "${v:-0}" "$MIN_RSYNC" || die "the distribution's rsync ($distro) is ${v:-unknown}; SBU needs >= $MIN_RSYNC (use --keep-source-rsync to keep the compiled one)"
		ok "rsync package: $distro $v"
	fi

	[ -e "$LEGACY_RSYNC" ] || return 0
	lv="$(rsync_version "$LEGACY_RSYNC")"
	if [ -n "$distro" ] && [ "$LEGACY_RSYNC" -ef "$distro" ]; then
		info "$LEGACY_RSYNC is the distribution's rsync - left as is"
	elif pkg_owns "$LEGACY_RSYNC"; then
		ver_ge "${lv:-0}" "$MIN_RSYNC" || die "$LEGACY_RSYNC (owned by a package) is ${lv:-unknown} and shadows the distribution's rsync; SBU needs >= $MIN_RSYNC"
		warn "$LEGACY_RSYNC belongs to a package, so it is left in place; it comes first on most PATHs, so SBU will use it"
	elif [ "$KEEP_SOURCE_RSYNC" -eq 1 ]; then
		ver_ge "${lv:-0}" "$MIN_RSYNC" || die "$LEGACY_RSYNC is ${lv:-unknown}; SBU needs >= $MIN_RSYNC"
		PIN_RSYNC=1
		ok "keeping compiled rsync $LEGACY_RSYNC $lv (--keep-source-rsync)"
	else
		RETIRE_RSYNC=1
		info "compiled rsync $LEGACY_RSYNC ${lv:-?} (from the 0.4.5 installer) will be renamed to $RETIRED_RSYNC so SBU uses the distribution's rsync"
	fi
}

retire_legacy_rsync() {
	local target="$RETIRED_RSYNC"
	[ -e "$target" ] && target="$RETIRED_RSYNC.$TS"
	mv "$LEGACY_RSYNC" "$target" || { fail "could not rename $LEGACY_RSYNC"; return 1; }
	echo "$target" > "$BACKUP_DIR/.retired-rsync"
	hash -r
	ok "renamed $LEGACY_RSYNC -> $target; SBU now uses $(distro_rsync) $(rsync_version "$(distro_rsync)")"
}

check_other_processes() {
	local p
	for p in $(sbu_script_pids restart-on-idle.sh); do
		warn "restart-on-idle.sh (pid $p) from an earlier upgrade is still looping; it can never match the '<job> - idle' status and will be stopped"
	done
}

# ---------------------------------------------------------------------------------------------
# Phases shared by upgrade and rollback
# ---------------------------------------------------------------------------------------------
STOPPED_JOBS=()
restart_jobs() { # NAME...
	local name i pid run_path="$PATH"
	[ "$PIN_RSYNC" -eq 1 ] && run_path="/usr/local/bin:$PATH"
	for name in "$@"; do
		( cd / && env PATH="$run_path" setsid "$SBU_HOME/sbu" --start "$name" < /dev/null >> "$LOG" 2>&1 )
		pid=""
		for i in 1 2 3 4 5 6 7 8 9 10; do pid="$(runjob_pids "$name" | head -n1)"; [ -n "$pid" ] && break; sleep 0.5; done
		if [ -n "$pid" ]; then ok "restarted $name (pid $pid)"; else fail "$name did not start - check $LOG_DIR/$name/sbulog"; fi
	done
}

quiesce() {
	local name deadline p
	for p in $(sbu_script_pids restart-on-idle.sh); do kill -TERM "$p" 2>/dev/null; done
	STOPPED_JOBS=()
	[ "${#RUNNING_JOBS[@]}" -eq 0 ] && { info "no jobs are running"; return 0; }
	deadline=$(( $(date +%s) + TIMEOUT ))
	trap 'info "interrupted - restarting jobs that were stopped"; restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}; die "aborted by user; nothing was installed" 3' INT TERM
	for name in ${RUNNING_JOBS[@]+"${RUNNING_JOBS[@]}"}; do
		if stop_job_when_idle "$name" "$deadline"; then
			STOPPED_JOBS+=("$name"); ok "stopped $name while idle"
		else
			warn "$name did not become idle within ${TIMEOUT}s"
			restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}
			trap - INT TERM
			die "quiesce timed out - nothing was installed; stopped jobs were restarted (retry with --timeout)" 3
		fi
	done
	trap - INT TERM
}

clean_transient_state() { # MODE=upgrade|rollback
	local name dest f jobdir m queue
	for name in $(list_jobs); do
		dest="${JOB_DEST[$name]:-}"; jobdir="$SBU_HOME/jobs/$name"
		# stale in-progress markers (nothing is running now); run-job only clears three of these
		for m in "${MARKERS[@]}"; do
			[ -e "$jobdir/$name-$m" ] && { rm -f "$jobdir/$name-$m"; info "$name: cleared stale marker $name-$m"; }
		done
		[ -n "$dest" ] && [ -d "$dest/$name/tmp" ] || continue
		if [ "$1" = "upgrade" ]; then
			# 0.4.5 change lists were named after the interval: tmp/<N>-min
			for f in "$dest/$name/tmp/"*-min; do
				[ -e "$f" ] || continue
				[[ "$(basename "$f")" =~ ^[0-9]+-min$ ]] || continue
				rm -f "$f"; info "$name: removed 0.4.5 change list $(basename "$f")"
			done
			# Retire the staging copy 0.4.5 pre-built with symlink-dereferencing `cp -rpl`.
			# It holds only hard links of snapshots/<job>.0, so 0.5.0 can rebuild it with cp -rpld.
			if [ -d "$dest/$name/tmp/$name.0" ]; then
				mv "$dest/$name/tmp/$name.0" "$dest/$name/tmp/.$name.0.pre-$TO_VERSION.deleting" || { warn "$name: could not retire tmp/$name.0"; continue; }
				queue="$SBU_HOME/delqueue/$name.pre-$TO_VERSION-staging-delfiles.sh"
				{
					echo "#!/bin/bash"
					echo "if [ ! -d \"$dest/$name/tmp/.$name.0.pre-$TO_VERSION.deleting\" ]; then"
					echo "rm -rf $queue"
					echo "else"
					echo "nohup rm -rf \"$dest/$name/tmp/.$name.0.pre-$TO_VERSION.deleting\" &>/dev/null &"
					echo "fi"
				} > "$queue"
				chmod a+x "$queue"
				( cd / && setsid nohup bash -c 'rm -rf "$1" && rm -f "$2"' _ "$dest/$name/tmp/.$name.0.pre-$TO_VERSION.deleting" "$queue" < /dev/null &> /dev/null & )
				info "$name: retired 0.4.5 staging copy tmp/$name.0 (deleting in background via delqueue)"
			fi
		else
			[ -e "$dest/$name/tmp/$name-changes" ] && { rm -f "$dest/$name/tmp/$name-changes"; info "$name: removed 0.5.0 change list"; }
		fi
	done
}

autostart_pin() { # add|remove
	local f="$SBU_HOME/source/autostart.sh" tmp
	[ -f "$f" ] || return 0
	tmp="$(mktemp "$f.XXXXXX")" || return 1
	if [ "$1" = "add" ]; then
		if grep -qF 'sbu-upgrade-0.5.0' "$f"; then rm -f "$tmp"; return 0; fi
		awk -v line="$PIN_LINE" 'NR==1 && /^#!/ { print; print line; next } NR==1 { print line } { print }' "$f" > "$tmp"
	else
		grep -vF 'sbu-upgrade-0.5.0' "$f" > "$tmp"
	fi
	chmod --reference="$f" "$tmp" 2>/dev/null || chmod 0755 "$tmp"
	mv -f "$tmp" "$f"
}

confirm() {
	[ "$ASSUME_YES" -eq 1 ] && return 0
	[ -t 0 ] || die "not running interactively; re-run with --yes to proceed"
	local a; read -r -p "  $1 [y/N] " a
	[[ "$a" =~ ^[Yy] ]] || { echo "  Cancelled - nothing was changed."; cleanup_work; exit 0; }
}

open_log() { mkdir -p "$LOG_DIR" && : >> "$LOG" && LOG_READY=1; }

# ---------------------------------------------------------------------------------------------
# Modes
# ---------------------------------------------------------------------------------------------
do_preflight() {
	step "Preflight"
	preflight_common
	local cur; cur="$(installed_version)"
	if [ "$cur" = "$TO_VERSION" ]; then
		ok "SBU $TO_VERSION is already installed - nothing to do"
		[ "$MODE" = "check" ] || { cleanup_work; exit 0; }
		return 0
	fi
	if [ "$cur" != "$FROM_VERSION" ]; then
		[ "$FORCE" -eq 1 ] || die "installed version is '$cur'; this upgrade is validated only for $FROM_VERSION (use --force to override)"
		warn "installed version is '$cur', not $FROM_VERSION - continuing because of --force"
	else
		ok "installed version: $cur"
	fi
	resolve_package
	local mism; mism="$(verify_tree_against_manifest "$PKG_DIR")"
	if [ -n "$mism" ] && [ "$(sha_of "$PKG_DIR/source/sync-changes.sh")" = "bea53122948af12846f136e84ff775bf70940cee4008899d4707eecd067098b4" ]; then
		[ "$FORCE" -eq 1 ] || die "package at $PKG_DIR is the original 0.5.0 build without the FullSync=off and --stop fixes.
Use sbu-0_5_0-fixed.zip (or apply the fix patch to your repo) and pass it with --package."
	fi
	if [ -n "$mism" ]; then
		[ "$FORCE" -eq 1 ] || die "package at $PKG_DIR differs from the validated $TO_VERSION build:
$mism
(use --force to install it anyway)"
		warn "package differs from the validated build (--force):"; printf '%s\n' "$mism" | sed 's/^/           /'
	else
		ok "package $PKG_DIR matches the validated $TO_VERSION manifest"
	fi
	local f bad=0
	for f in "$PKG_DIR"/sbu "$PKG_DIR"/source/*.sh "$PKG_DIR"/source/functions "$PKG_DIR"/source/header; do
		bash -n "$f" 2>/dev/null || { fail "syntax error in package file ${f#"$PKG_DIR"/}"; bad=1; }
	done
	[ "$bad" -eq 0 ] || die "package contains scripts that do not parse"
	check_rsync
	inventory_jobs
	ok "$(list_jobs | wc -l) job(s) found; running: ${RUNNING_JOBS[*]:-none}"
	check_other_processes
	local anc="$BACKUP_ROOT"; while [ ! -d "$anc" ]; do anc="$(dirname "$anc")"; done
	local free; free=$(df -Pk "$anc" | awk 'NR==2{print $4}')
	local need; need=$(du -sk "$SBU_HOME" 2>/dev/null | awk '{print $1*2+1024}')
	[ "${free:-0}" -gt "${need:-0}" ] || die "not enough space under $anc for the pre-upgrade backup (${need} KB needed)"
}

do_upgrade() {
	step "Plan"
	info "SBU $(installed_version) -> $TO_VERSION"
	info "jobs to stop and restart: ${RUNNING_JOBS[*]:-none}$([ "$NO_RESTART" -eq 1 ] && echo ' (will be left stopped: --no-restart)')"
	info "backup of $SBU_HOME -> $BACKUP_ROOT/opt-sbu-$FROM_VERSION-$TS"
	info "snapshots, job configs and job state are not modified"
	[ "$WARNINGS" -gt 0 ] && info "$WARNINGS warning(s) above - please read them"
	[ "$RETIRE_RSYNC" -eq 1 ] && info "compiled $LEGACY_RSYNC will be renamed to $RETIRED_RSYNC"
	confirm "Proceed with the upgrade?"

	if [ "$NEED_RSYNC_PKG" -eq 1 ]; then
		step "Installing the distribution's rsync"
		pm_install_rsync >> "$LOG" 2>&1 || die "could not install the rsync package with $(detect_pm) - nothing was changed"
		hash -r; NEED_RSYNC_PKG=0
		check_rsync
		[ -n "$(distro_rsync)" ] || die "rsync package installed but not found in $SYSTEM_PATH - nothing else was changed"
	fi

	step "Stopping jobs (waiting for each to be idle)"
	quiesce

	step "Backing up $SBU_HOME"
	BACKUP_DIR="$BACKUP_ROOT/opt-sbu-$FROM_VERSION-$TS"
	mkdir -p "$BACKUP_ROOT" && cp -a "$SBU_HOME" "$BACKUP_DIR" || { restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}; die "backup failed - nothing was installed" 4; }
	ok "backup at $BACKUP_DIR"

	step "Installing $TO_VERSION"
	local files=() rel
	while read -r rel; do is_runtime_file "$rel" || files+=("$rel"); done < <(manifest_files)
	trap '' INT TERM
	if ! install_tree "$PKG_DIR" ${files[@]+"${files[@]}"}; then
		fail "install failed - restoring $FROM_VERSION from $BACKUP_DIR"
		local back=(); while read -r rel; do is_runtime_file "$rel" || back+=("$rel"); done < <(cd "$BACKUP_DIR" && find sbu docs source -type f | sort)
		install_tree "$BACKUP_DIR" ${back[@]+"${back[@]}"} || fail "automatic restore failed - restore manually from $BACKUP_DIR"
		find "$SBU_HOME" -name '.*.sbu-upgrade.*' -delete 2>/dev/null
		restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}
		trap - INT TERM
		die "upgrade failed; $FROM_VERSION restored" 4
	fi
	trap - INT TERM
	ok "installed ${#files[@]} files (kept: source/autostart.sh)"
	for rel in "${OBSOLETE_FILES[@]}"; do
		[ -e "$SBU_HOME/$rel" ] && rm -f "$SBU_HOME/$rel" && info "removed obsolete $rel"
	done

	step "Migrating transient job state"
	clean_transient_state upgrade
	if [ "$RETIRE_RSYNC" -eq 1 ]; then retire_legacy_rsync; fi
	if [ "$PIN_RSYNC" -eq 1 ]; then autostart_pin add && ok "autostart.sh keeps /usr/local/bin first on PATH"; fi

	step "Verifying"
	local mism; mism="$(cd "$SBU_HOME" && for rel in ${files[@]+"${files[@]}"}; do
		[ "$(sha_of "$rel")" = "$(awk -v r="$rel" '$2==r{print $1}' <<< "$MANIFEST")" ] || echo "$rel"; done)"
	[ -z "$mism" ] && ok "installed files match the manifest" || fail "installed files differ from manifest: $mism"
	[ "$(installed_version)" = "$TO_VERSION" ] && ok "sbu --version: $("$SBU_HOME/sbu" --version)" || fail "version file is not $TO_VERSION"
	local name
	for name in $(list_jobs); do
		if ( [ "$PIN_RSYNC" -eq 1 ] && PATH="/usr/local/bin:$PATH"; source "$SBU_HOME/source/functions" && load_job_config "$name" && [ -n "$SOURCE" ] && [ -n "$DEST" ] ) >/dev/null 2>&1; then
			ok "$TO_VERSION reads job config: $name"
		else
			fail "$TO_VERSION cannot read job config: $name"
		fi
	done

	if [ "$NO_RESTART" -eq 0 ] && [ "${#STOPPED_JOBS[@]}" -gt 0 ]; then
		step "Restarting jobs"
		restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}
	elif [ "${#STOPPED_JOBS[@]}" -gt 0 ]; then
		info "left stopped (--no-restart): ${STOPPED_JOBS[*]} - start with: $SBU_HOME/sbu --start JOB"
	fi

	step "Done"
	[ "$FAILURES" -gt 0 ] && { echo "  Upgrade finished with $FAILURES failure(s). Log: $LOG"; echo "  Roll back with: $0 --rollback $BACKUP_DIR"; cleanup_work; exit 4; }
	echo "  SBU upgraded to $TO_VERSION. Log: $LOG"
	echo "  Roll back with: $0 --rollback $BACKUP_DIR"
}

do_rollback() {
	step "Rollback preflight"
	preflight_common
	local dir="$ROLLBACK_DIR"
	if [ -z "$dir" ]; then
		dir="$(ls -1d "$BACKUP_ROOT"/opt-sbu-* 2>/dev/null | sort | tail -n1)"
		[ -n "$dir" ] || die "no backups found in $BACKUP_ROOT"
	fi
	[ -f "$dir/sbu" ] && [ -f "$dir/docs/version" ] && [ -f "$dir/source/functions" ] || die "$dir is not an SBU backup"
	local bver; bver="$(tr -d '[:space:]' < "$dir/docs/version")"
	info "restore SBU $bver from $dir (currently $(installed_version))"
	PIN_RSYNC=0
	inventory_jobs 2>/dev/null
	info "jobs to stop and restart: ${RUNNING_JOBS[*]:-none}"
	confirm "Proceed with the rollback?"

	step "Stopping jobs (waiting for each to be idle)"
	quiesce
	step "Restoring $bver code"
	local files=() rel
	while read -r rel; do is_runtime_file "$rel" || files+=("$rel"); done < <(cd "$dir" && find sbu docs source -type f | sort)
	trap '' INT TERM
	install_tree "$dir" ${files[@]+"${files[@]}"} || { trap - INT TERM; die "restore failed - copy files from $dir manually" 4; }
	trap - INT TERM
	autostart_pin remove
	clean_transient_state rollback
	local retired=""
	[ -f "$dir/.retired-rsync" ] && retired="$(cat "$dir/.retired-rsync")"
	if [ -n "$retired" ] && [ -e "$retired" ] && [ ! -e "$LEGACY_RSYNC" ]; then
		mv "$retired" "$LEGACY_RSYNC" && ok "restored compiled rsync $LEGACY_RSYNC $(rsync_version "$LEGACY_RSYNC")"
	fi
	if grep -q "$LEGACY_RSYNC" "$SBU_HOME/source/search-for-changes.sh" 2>/dev/null && [ ! -e "$LEGACY_RSYNC" ]; then
		ln -s "$(distro_rsync)" "$LEGACY_RSYNC" && warn "$bver hardcodes $LEGACY_RSYNC, which did not exist; linked it to $(distro_rsync)"
	fi
	[ "$(installed_version)" = "$bver" ] && ok "sbu --version: $("$SBU_HOME/sbu" --version)" || fail "version is not $bver after restore"
	if [ "$NO_RESTART" -eq 0 ] && [ "${#STOPPED_JOBS[@]}" -gt 0 ]; then step "Restarting jobs"; restart_jobs ${STOPPED_JOBS[@]+"${STOPPED_JOBS[@]}"}; fi
	step "Done"
	echo "  Rolled back to $bver. Log: $LOG"
	[ "$FAILURES" -eq 0 ] || exit 4
}

# ---------------------------------------------------------------------------------------------
main() {
	echo "SBU upgrade utility ($FROM_VERSION -> $TO_VERSION)"
	[ "$(id -u)" -eq 0 ] && open_log
	case "$MODE" in
		check)
			do_preflight
			step "Result"
			if [ "$FAILURES" -gt 0 ]; then echo "  Preflight failed."; cleanup_work; exit 1; fi
			echo "  Preflight passed with $WARNINGS warning(s). Nothing was changed."
			;;
		upgrade)  do_preflight; do_upgrade ;;
		rollback) do_rollback ;;
	esac
	cleanup_work
}
main
