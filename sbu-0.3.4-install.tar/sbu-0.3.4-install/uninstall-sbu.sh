#!/bin/bash
### --------------------------------- ###
###     Copyright 2016 Luke Higgs     ###
### Contact: admin@aquariandesign.com ###
### --------------------------------- ###

# This file is part of SBU (Snapshot Backup Utility)

# SBU is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# any later version.

# SBU is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with SBU (located in /opt/sbu/docs/COPYING).  If not, see <http://www.gnu.org/licenses/>.
#################################################################################################

echo ""
echo "-----UNINSTALLING SBU-----"
echo ""
if [ ! -d "/opt" ]; then
	echo "/opt directory not found or not accessible, uninstall cannot continue!"
else
	rm -rf /opt/sbu
fi

if [ ! -d "/var/log" ]; then
	echo "/var/log directory not found or not accessible, uninstall cannot continue!"
else
	rm -rf /var/log/sbu
fi

if [ -e "/etc/rc.local" ]; then
	grep -v "exit 0" /etc/rc.local > /etc/rc.local.tmp; mv /etc/rc.local.tmp /etc/rc.local
	grep -v "# SBU Autostart script:" /etc/rc.local > /etc/rc.local.tmp; mv /etc/rc.local.tmp /etc/rc.local
	grep -v "/opt/sbu/source/autostart.sh" /etc/rc.local > /etc/rc.local.tmp; mv /etc/rc.local.tmp /etc/rc.local
	echo "" >> /etc/rc.local
	echo "exit 0" >> /etc/rc.local
	chmod +x /etc/rc.local
else
	echo "/etc/rc.local does not exist!"
fi

echo "SBU has been removed from your system! No backup files have been deleted, you will need to delete these manually."
echo ""
